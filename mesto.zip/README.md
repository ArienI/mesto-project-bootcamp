# Проект: Место [![Сайт проекта](https://img.shields.io/badge/website-up-blue)](https://arieni.github.io/mesto-project-bootcamp/)

### Обзор

- Intro
- Figma
- Картинки

**Интро**

Проект создание фотоальбома - это третья проектная работа. Основное отличие её от первых - это работа не только с версткой, но и с JS.

Веб-страница созданна на основе макета в Figma .

**Figma**

- [Ссылка на макет в Figma](https://www.figma.com/file/2cn9N9jSkmxD84oJik7xL7/JavaScript.-Sprint-4?node-id=0%3A1)
- [Ссылка на макет в Figma](https://www.figma.com/file/bjyvbKKJN2naO0ucURl2Z0/JavaScript.-Sprint-5?node-id=50160%3A169&mode=dev)

**Картинки**

оптимизация картинок [оптимизировать картинки](https://tinypng.com/)
